import React from 'react';
import 'devextreme/dist/css/dx.light.css';
import './App.css';
import DataGrid, { Column, Pager, Paging } from 'devextreme-react/data-grid';
import { PivotGrid, Scrolling, Export } from 'devextreme-react/pivot-grid';
// import employees from './employees';
import employees from './data';
const staffs = {
    remoteOperations: false,
    store: employees(100000),
    fields: getFieldData(),
};
// debugger;
function App() {
    // const staffs = employees(100000);
    const allowedPageSizes = [10, 20, 500, 1000, 5000, 10000, 100000];
    return (
        <div className="App">
            <PivotGrid
                id="pivotgrid"
                dataSource={staffs}
                allowSortingBySummary={true}
                allowFiltering={true}
                showBorders={true}
                showColumnTotals={false}
                showColumnGrandTotals={false}
                showRowTotals={false}
                showRowGrandTotals={false}
            >
                <Scrolling mode="virtual" />
                <Export enabled={true} />
            </PivotGrid>
        </div>
    );
}

export default App;

function getFieldData() {
    return [
        {
            caption: 'level_0',
            dataField: 'level_0',
            // width: 250,
            // sortBySummaryField: 'manager',
            // sortBySummaryPath: [],
            // sortOrder: 'asc',
            area: 'row',
        },
        {
            caption: 'level_1',
            dataField: 'level_1',
            // width: 250,
            area: 'row',
        }, {
            caption: 'level_2',
            dataField: 'level_2',
            // width: 250,
            area: 'row',
        }, {
            caption: 'level_3',
            dataField: 'level_3',
            // width: 250,
            area: 'row',
        }, {
            caption: 'level_4',
            dataField: 'level_4',
            // width: 250,
            area: 'row',
        }, {
            caption: 'jobTitle',
            dataField: 'jobTitle',
            width: 250,
            // sortBySummaryField: 'EmployeeID',
            // sortBySummaryPath: [],
            // sortOrder: 'desc',
            area: 'row',
        }, /*{
            caption: 'employmentType',
            dataField: 'employmentType',
            // area: 'row',
            // sortBySummaryField: 'EmployeeID',
            // sortBySummaryPath: [],
            // sortOrder: 'desc',
            area: 'column',
        }, {
            caption: 'Percentage %',
            dataField: 'percentage',
            // dataType: 'date',
            tooltip: "Percentage %",
            area: 'column',
        }, {
            caption: 'Monday <br/> 01/05/2022',
            dataField: 'mon',
            // summaryType: 'sum',
            //   format: 'currency',
            area: 'column',
        }, {
            caption: 'Tuesday \n 02/05/2022',
            dataField: 'tue',
            area: 'row',
        }, {
            caption: 'Wednessday \n 03/05/2022',
            dataField: 'wed',
            area: 'row',
        }, {
            caption: 'Thursday \n 04/05/2022',
            dataField: 'thu',
            area: 'row',
        }, {
            caption: 'Friday \n 05/05/2022',
            dataField: 'fri',
            area: 'row',
        }, {
            caption: 'Saturday \n 06/05/2022',
            dataField: 'sat',
            area: 'row',
            // summaryType: 'sum',
        }, {
            caption: 'Sunday \n 07/05/2022',
            dataField: 'sun',
            area: 'row',
            // summaryType: 'sum',
        }, {
            dataField: 'EmployeeID',
            visible: false,
        }*/
    ];
}