const appInfo = {
    title: 'demo'
};
export default appInfo;

